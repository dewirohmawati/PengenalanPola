package com.dewi.presensirswardiwaluyo;

import android.app.Activity;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.dewi.presensirswardiwaluyo.model.PegawaiModel;
import com.dewi.presensirswardiwaluyo.table.PegawaiTable;
import com.dewi.presensirswardiwaluyo.util.NetworkManager;
import com.dewi.presensirswardiwaluyo.util.Progressive;
import com.dewi.presensirswardiwaluyo.util.VolleyUtil;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * Created by Dewi Rohmawati on 8/13/2016.
 */
public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();
    private DecoratedBarcodeView barcodeView;
    private VolleyUtil volley;
    private LinearLayout layoutNIP;
    private LinearLayout layoutNama;
    private LinearLayout layoutJabatan;
    private LinearLayout layoutDinas;
    private TextView txtNIP;
    private TextView txtNama;
    private TextView txtJabatan;
    private TextView txtDinas;
    private ImageView imageView;

    //callback method
    private BarcodeCallback callback = new BarcodeCallback() {
        @Override
        public void barcodeResult(BarcodeResult result) {
            if (result.getText() != null) {
                String idPegawai = result.getText();

                pause(barcodeView);
                barcodeView.setStatusText(idPegawai);

                if (NetworkManager.isNetworkAvailable(MainActivity.this)) {
                    checkPegawai(idPegawai);
                }
            }

            imageView.setImageBitmap(result.getBitmapWithResultPoints(Color.YELLOW));
        }

        @Override
        public void possibleResultPoints(List<ResultPoint> resultPoints) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.continuous_scan);

        initView();
        setContentLayoutVisibility(View.INVISIBLE);

        barcodeView.decodeContinuous(callback);
        barcodeView.setStatusText("Tempatkan QR code pada kotak agar dapat di pindai");

        volley = VolleyUtil.getInstance();

        volley.setContext(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        barcodeView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();

        barcodeView.pause();
    }

    public void pause(View view) {
        barcodeView.pause();
    }

    public void resume(View view) {
        barcodeView.resume();
    }

    public void triggerScan(View view) {
        barcodeView.decodeSingle(callback);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return barcodeView.onKeyDown(keyCode, event) || super.onKeyDown(keyCode, event);
    }

    private void initView() {
        barcodeView = (DecoratedBarcodeView) findViewById(R.id.barcode_scanner);
        layoutNIP = (LinearLayout) findViewById(R.id.layoutNIP);
        layoutNama = (LinearLayout) findViewById(R.id.layoutNama);
        layoutJabatan = (LinearLayout) findViewById(R.id.layoutJabatan);
        layoutDinas = (LinearLayout) findViewById(R.id.layoutDinas);
        txtNIP = (TextView) findViewById(R.id.txtNIP);
        txtNama = (TextView) findViewById(R.id.txtNama);
        txtJabatan = (TextView) findViewById(R.id.txtJabatan);
        txtDinas = (TextView) findViewById(R.id.txtDinas);
        imageView = (ImageView) findViewById(R.id.barcodePreview);
    }

    private void setContentLayoutVisibility(int visibility) {
        layoutNIP.setVisibility(visibility);
        layoutNama.setVisibility(visibility);
        layoutJabatan.setVisibility(visibility);
        layoutDinas.setVisibility(visibility);
    }

    private void checkPegawai(final String idPegawai) {
        JsonArrayRequest request = new JsonArrayRequest(WebEnvirontment.GET_PEGAWAI_BY_ID + "?id_pegawai=" + idPegawai,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        if (response != null) {
                            PegawaiModel pegawaiModel = new PegawaiModel();
                            JSONArray jsonArray = response;

                            for (int i = 0; i < jsonArray.length(); i++) {
                                try {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                                    pegawaiModel.setIdPegawai(jsonObject.getString(PegawaiTable.ID_PEGAWAI));
                                    pegawaiModel.setIdJabatan(jsonObject.getString(PegawaiTable.ID_JABATAN));
                                    pegawaiModel.setJenisKelamin(jsonObject.getString(PegawaiTable.JENIS_KELAMIN));
                                    pegawaiModel.setKontak(jsonObject.getString(PegawaiTable.KONTAK));
                                    pegawaiModel.setTglLahir(jsonObject.getString(PegawaiTable.TGL_LAHIR));
                                    pegawaiModel.setAlamat(jsonObject.getString(PegawaiTable.ALAMAT));
                                    pegawaiModel.setNama(jsonObject.getString(PegawaiTable.NAMA));
                                    pegawaiModel.setJabatan(jsonObject.getString(PegawaiTable.JABATAN));

                                    Log.d("ISI JSON", jsonObject.toString());
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }

                            doPresensi(pegawaiModel);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();

                        resume(barcodeView);
                    }
                }
        );

        volley.getRequestQueue().add(request);
    }

    private void doPresensi(final PegawaiModel pegawaiModel) {
        final Progressive progressive = new Progressive(this);

        progressive.show(this);

        JsonArrayRequest request = new JsonArrayRequest(WebEnvirontment.DO_PRESENSI
                + "?id_pegawai=" + pegawaiModel.getIdPegawai()
                + "&id_dinas=" + 3,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        progressive.dismiss();

                        JSONArray jsonArray = response;
                        try {
                            JSONObject jsonObject = jsonArray.getJSONObject(0);

                            String status = jsonObject.getString("data");

                            if (status.equals("sukses")) {
                                txtNIP.setText(pegawaiModel.getIdPegawai());
                                txtNama.setText(pegawaiModel.getNama());
                                txtJabatan.setText(pegawaiModel.getJabatan());

                                setContentLayoutVisibility(View.VISIBLE);
                                barcodeView.setStatusText("Anda berhasil presensi");

                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        barcodeView.setStatusText("Memulai untuk memindai kembali..");

                                        new Handler().postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                barcodeView.setStatusText("Tempatkan QR code pada kotak agar dapat di pindai");
                                                setContentLayoutVisibility(View.INVISIBLE);
                                                imageView.setImageBitmap(null);
                                                resume(barcodeView);
                                            }
                                        }, 3000);
                                    }
                                }, 3000);
                            } else if (status.equals("sukses update")) {
                                txtNIP.setText(pegawaiModel.getIdPegawai());
                                txtNama.setText(pegawaiModel.getNama());
                                txtJabatan.setText(pegawaiModel.getJabatan());

                                setContentLayoutVisibility(View.VISIBLE);

                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        barcodeView.setStatusText("Memulai untuk memindai kembali..");

                                        new Handler().postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                barcodeView.setStatusText("Tempatkan QR code pada kotak agar dapat di pindai");
                                                setContentLayoutVisibility(View.INVISIBLE);
                                                imageView.setImageBitmap(null);
                                                resume(barcodeView);
                                            }
                                        }, 3000);
                                    }
                                }, 3000);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }
        );

        volley.getRequestQueue().add(request);
    }
}