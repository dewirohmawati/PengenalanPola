package com.dewi.presensirswardiwaluyo.util;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;

/**
 * Created by Dewi Rohmawati on 6/6/2016.
 */
public class Progressive extends Dialog {

    private ProgressDialog progressDialog;

    public Progressive(Context context) {
        super(context);
    }

    public void show(Context context) {
        progressDialog = new ProgressDialog(context);

        progressDialog.setCancelable(false);
        progressDialog.setTitle("Loading...");
        progressDialog.show();
    }

    public void dismiss() {
        if(progressDialog != null)
            progressDialog.dismiss();
    }

}
