package com.dewi.presensirswardiwaluyo.util;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Created by Dewi Rohmawati on 5/30/2016.
 */
public class VolleyUtil {

    private static VolleyUtil instance = new VolleyUtil();
    private RequestQueue requestQueue;
    private Context context;

    private VolleyUtil() {
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public static synchronized VolleyUtil getInstance() {
        return instance;
    }

    public RequestQueue getRequestQueue() {
        if(requestQueue == null) {
            requestQueue = Volley.newRequestQueue(context);

            return requestQueue;
        } else
            return requestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req, String tag) {
        getRequestQueue().add(req);
    }

    public <T> void addToRequestQueue(Request<T> req) {
        getRequestQueue().add(req);
    }

    public void cancelPendingReq(Object tag) {
        if (requestQueue != null)
            requestQueue.cancelAll(tag);
    }
}
