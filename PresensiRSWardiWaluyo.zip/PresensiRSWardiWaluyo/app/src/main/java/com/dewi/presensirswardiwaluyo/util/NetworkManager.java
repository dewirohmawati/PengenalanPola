package com.dewi.presensirswardiwaluyo.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * Created by Dewi Rohmawati on 6/2/2016.
 */
public class NetworkManager {

    private NetworkManager() {
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] networkInfos = connectivityManager.getAllNetworkInfo();

        for(NetworkInfo networkInfo : networkInfos)
            if(networkInfo.getState() == NetworkInfo.State.CONNECTED)
                return true;

        return false;
    }

}
