package com.dewi.presensirswardiwaluyo;

/**
 * Created by Dewi Rohmawati on 8/13/2016.
 */
public interface WebEnvirontment {

    String GET_PEGAWAI_BY_ID = "http://rsmardiwaluyo.hol.es/api/android/get-pegawai.php";
    String DO_PRESENSI = "http://rsmardiwaluyo.hol.es/api/android/do-presensi.php";
    String GET_ALL_DINAS = "http://rsmardiwaluyo.hol.es/api/android/fetch_all_dinas.php";

}
