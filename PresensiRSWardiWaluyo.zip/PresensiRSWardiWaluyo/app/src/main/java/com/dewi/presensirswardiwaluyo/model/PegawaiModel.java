package com.dewi.presensirswardiwaluyo.model;

/**
 * Created by Dewi Rohmawati on 8/13/2016.
 */
public class PegawaiModel {

    private String idPegawai;
    private String nama;
    private String tglLahir;
    private String jenisKelamin;
    private String alamat;
    private String kontak;
    private String idJabatan;
    private String jabatan;

    public PegawaiModel() {
    }

    public PegawaiModel(String alamat, String idJabatan, String idPegawai, String jabatan, String jenisKelamin, String kontak, String tglLahir, String nama) {
        this.alamat = alamat;
        this.idJabatan = idJabatan;
        this.idPegawai = idPegawai;
        this.jabatan = jabatan;
        this.jenisKelamin = jenisKelamin;
        this.kontak = kontak;
        this.tglLahir = tglLahir;
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getIdJabatan() {
        return idJabatan;
    }

    public void setIdJabatan(String idJabatan) {
        this.idJabatan = idJabatan;
    }

    public String getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(String idPegawai) {
        this.idPegawai = idPegawai;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTglLahir() {
        return tglLahir;
    }

    public void setTglLahir(String tglLahir) {
        this.tglLahir = tglLahir;
    }

    public String getKontak() {
        return kontak;
    }

    public void setKontak(String kontak) {
        this.kontak = kontak;
    }

    public String getJabatan() {
        return jabatan;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }
}
