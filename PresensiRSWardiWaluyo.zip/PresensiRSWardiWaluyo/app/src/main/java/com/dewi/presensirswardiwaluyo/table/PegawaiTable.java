package com.dewi.presensirswardiwaluyo.table;

/**
 * Created by Dewi Rohmawati on 8/13/2016.
 */
public interface PegawaiTable {

    String ID_PEGAWAI = "id_pegawai";
    String NAMA = "nama";
    String TGL_LAHIR = "tgl_lahir";
    String JENIS_KELAMIN = "jenis_kelamin";
    String ALAMAT = "alamat";
    String KONTAK = "kontak";
    String ID_JABATAN = "id_jabatan";
    String JABATAN = "nama_jabatan";
}
